package com.example.stepstodolist;

import org.junit.Test;

import static org.junit.Assert.*;

public class ListDataActivityTest {

    @Test
    public void onCreate() {
    }
}