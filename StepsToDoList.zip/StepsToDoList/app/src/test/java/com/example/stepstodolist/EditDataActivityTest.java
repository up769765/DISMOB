package com.example.stepstodolist;

import org.junit.Test;

import static org.junit.Assert.*;

public class EditDataActivityTest {

    @Test
    public void onCreate() {
    }
}