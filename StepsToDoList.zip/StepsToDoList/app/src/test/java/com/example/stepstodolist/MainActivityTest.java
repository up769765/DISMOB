package com.example.stepstodolist;

import org.junit.Test;


import static org.junit.Assert.*;

public class MainActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void addData() {

        assertEquals("Hello", "Hello");
    }

    @Test
    public void onResume() {
    }

    @Test
    public void onPause() {
    }

    @Test
    public void onSensorChanged() {
        assertEquals(0, 0);
    }

    @Test
    public void onAccuracyChanged() {
    }
}