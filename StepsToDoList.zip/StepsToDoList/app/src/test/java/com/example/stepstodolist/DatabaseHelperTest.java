package com.example.stepstodolist;

import org.junit.Test;

import static org.junit.Assert.*;

public class DatabaseHelperTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onUpgrade() {
    }

    @Test
    public void addData() {
    }

    @Test
    public void getData() {
    }

    @Test
    public void getItemID() {
    }

    @Test
    public void updateName() {
    }

    @Test
    public void deleteName() {
    }
}